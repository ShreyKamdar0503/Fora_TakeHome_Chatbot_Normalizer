\
from fastapi import FastAPI, Response, status
from fastapi.responses import JSONResponse
from schemas import NormalizeRequest, NormalizeResponse, ErrorResponse, Contact, Entity, Enrichment
from classify import decide_category
from extract import extract_contact, extract_entities, cities_to_countries
from lib.textnorm import clean_text
from enrich import emergency_numbers_for_country, dedupe_numbers
import asyncio
import time
import os

APP_NAME = "normalize-service"
app = FastAPI(title=APP_NAME)

@app.get("/healthz")
def healthz():
    return {"status":"ok"}

@app.post("/normalize", response_model=NormalizeResponse, responses={400: {"model": ErrorResponse}, 415: {"model": ErrorResponse}})
async def normalize(req: NormalizeRequest):
    if not isinstance(req.text, str):
        return JSONResponse(status_code=415, content=ErrorResponse(
            error_code="UNSUPPORTED_MEDIA_TYPE",
            message="Body must be JSON with 'text' field as string.",
            hint="Send Content-Type: application/json"
        ).model_dump())
    start = time.perf_counter()
    text = clean_text(req.text)

    contact_data = extract_contact(text)
    contact = Contact(**contact_data) if any(contact_data.values()) else None

    entities_data = extract_entities(text)
    entities = [Entity(**e) for e in entities_data] if entities_data else None

    category = decide_category(text)

    enrichment = None
    if entities:
        country_codes = cities_to_countries(entities_data)
        if country_codes:
            # fetch numbers concurrently
            lists = await asyncio.gather(*[emergency_numbers_for_country(cc) for cc in country_codes])
            numbers = dedupe_numbers(lists)
            enrichment = Enrichment(local_emergency_numbers=numbers)
            # Add creative enrichment: language by country (deterministic tiny map)
            lang_map = {
                "US": "English",
                "FR": "French",
                "IT": "Italian",
                "ES": "Spanish",
                "DE": "German",
                "GB": "English",
                "JP": "Japanese",
                "AU": "English",
            }
            languages = list({lang_map.get(cc) for cc in country_codes if lang_map.get(cc)})
            if languages:
                # attach under creative_language
                setattr(enrichment, "creative_language", languages[0] if len(languages)==1 else languages)

    resp = NormalizeResponse(
        message_id=req.message_id,
        category=category,
        contact=contact,
        entities=entities,
        enrichment=enrichment
    )
    latency_ms = int((time.perf_counter()-start)*1000)
    # basic logging to stdout
    print({"message_id": req.message_id, "category": category, "latency_ms": latency_ms})
    return JSONResponse(status_code=200, content=resp.model_dump(exclude_none=True))

@app.exception_handler(Exception)
async def on_error(request, exc: Exception):
    return JSONResponse(status_code=500, content=ErrorResponse(
        error_code="INTERNAL_ERROR",
        message="Unexpected error.",
        hint=str(exc)
    ).model_dump())
