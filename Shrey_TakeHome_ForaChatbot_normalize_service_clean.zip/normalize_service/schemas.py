from pydantic import BaseModel, Field, EmailStr
#from pydantic import *
from typing import List, Optional, Literal, Dict, Any

Category = Literal["urgent","high_risk","base"]
EntityType = Literal["city","hotel","restaurant"]

class NormalizeRequest(BaseModel):
    message_id: str = Field(..., description="Echoed back in response")
    text: str

class Contact(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    zip: Optional[str] = None

class Entity(BaseModel):
    type: EntityType
    value: str

class Enrichment(BaseModel):
    local_emergency_numbers: Optional[List[str]] = None
    # Allow any extra computed creative_* fields
    model_config = {"extra": "allow"}

class NormalizeResponse(BaseModel):
    message_id: str
    category: Category
    contact: Optional[Contact] = None
    entities: Optional[List[Entity]] = None
    enrichment: Optional[Enrichment] = None

class ErrorResponse(BaseModel):
    error_code: str
    message: str
    hint: Optional[str] = None
