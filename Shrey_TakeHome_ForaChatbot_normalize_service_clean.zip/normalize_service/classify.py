\
import re
from typing import Literal

Category = Literal["urgent","high_risk","base"]

HIGH_RISK_PATTERNS = [
    # lost/misplaced/missing passport (both word orders)
    r"\b(lost|misplac(?:e|ed)|mislaid|missing)\b.*\bpassport\b",
    r"\bpassport\b.*\b(lost|misplac(?:e|ed)|mislaid|missing)\b",

    # stolen wallet/passport/credit card (both orders)
    r"\bstolen\b.*\b(passport|wallet|card|credit[-\s]?card)\b",
    r"\b(passport|wallet|card|credit[-\s]?card)\b.*\bstolen\b",

    r"\barrested\b|\bpolice\b|\bjail\b",
    r"\bhospital\b|\bmedical\b.*\b(emergency|urgent|help)\b",
    r"\bvisa\b.*\b(denied|refused|rejected)\b",
    r"\bscam(med)?\b|\bfraud\b",
    r"\bkidnap(?:ped|ping)?\b",
]

URGENT_PATTERNS = [
    r"\b(asap|immediately|urgent|right away|first thing)\b",
    r"\b(today|tonight|tomorrow)\b",
    r"\bin\s*\d+\s*(h|hr|hrs|hour|hours|min|mins|minute|minutes)\b",
    r"\b(\d+)\s*(h|hr|hrs|hour|hours)\b\s*(before|until)\b",
    r"\bflight\b.*\b(in|at)\s*\d+\s*(h|hr|hrs|hour|hours)\b",
]

def decide_category(text: str) -> Category:
    t = text.lower()
    for pat in HIGH_RISK_PATTERNS:
        if re.search(pat, t, flags=re.I):
            return "high_risk"
    for pat in URGENT_PATTERNS:
        if re.search(pat, t, flags=re.I):
            return "urgent"
    return "base"
