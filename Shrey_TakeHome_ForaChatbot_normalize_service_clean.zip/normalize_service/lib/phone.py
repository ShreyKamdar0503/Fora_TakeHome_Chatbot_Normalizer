import phonenumbers

def normalize_phone(raw: str, default_region: str = "US") -> str | None:
    try:
        num = phonenumbers.parse(raw, default_region)
        if not phonenumbers.is_possible_number(num) or not phonenumbers.is_valid_number(num):
            return None
        # return digits only for simplicity
        return "".join([c for c in phonenumbers.format_number(num, phonenumbers.PhoneNumberFormat.E164) if c.isdigit()])
    except Exception:
        return None
