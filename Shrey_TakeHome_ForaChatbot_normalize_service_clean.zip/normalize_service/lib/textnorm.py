import re
def clean_text(s: str) -> str:
    s = s.replace("\u2019", "'").replace("’", "'").replace("—","-")
    s = re.sub(r"\s+", " ", s).strip()
    return s
