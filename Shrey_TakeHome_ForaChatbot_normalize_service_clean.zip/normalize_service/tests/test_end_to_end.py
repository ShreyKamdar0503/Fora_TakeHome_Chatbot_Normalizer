\
import json
from fastapi.testclient import TestClient
from app import app

client = TestClient(app)

def post(text: str):
    return client.post("/normalize", json={"message_id":"t1","text":text})

def test_high_risk_paris():
    r = post("my wallet was stolen in Paris last night")
    assert r.status_code == 200
    data = r.json()
    assert data["category"] == "high_risk"
    ents = { (e["type"], e["value"]) for e in data.get("entities", []) }
    assert ("city","paris") in ents
    nums = data.get("enrichment",{}).get("local_emergency_numbers",[])
    assert "112" in nums

def test_urgent_flight_in_3h():
    r = post("flight in 3 h, need assistance")
    assert r.status_code == 200
    data = r.json()
    assert data["category"] == "urgent"
    assert data.get("entities") is None

def test_base_multi_city_hotel():
    r = post("planning Rome in October with a stay at Chapter Roma and maybe NYC")
    assert r.status_code == 200
    data = r.json()
    assert data["category"] == "base"
    ents = {(e["type"], e["value"]) for e in data.get("entities", [])}
    assert ("city","rome") in ents
    assert ("hotel","chapter roma") in ents
    assert ("city","new york city") in ents or ("city","new york") in ents
    nums = data.get("enrichment",{}).get("local_emergency_numbers",[])
    # Should include both EU 112 and US 911
    assert "112" in nums and "911" in nums

def test_partial_contact():
    r = post("Hi Fora, I'm Alex. My client is flying next week and just lost her passport—help!")
    assert r.status_code == 200
    data = r.json()
    assert data["category"] == "high_risk"
    assert data["contact"]["first_name"] == "Alex"
