\
import re
import csv
from typing import Dict, List, Optional, Tuple
from pathlib import Path
from rapidfuzz import process, fuzz
from lib.phone import normalize_phone

NAME_PAT = re.compile(r"\b(i['’]m|i am|this is)\s+([A-Z][a-z]+)(?:\s+([A-Z][a-z]+))?", flags=re.I)
EMAIL_PAT = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
ZIP_PAT = re.compile(r"\b\d{5}(?:-\d{4})?\b")
ZIP_ENTITY_PAT = re.compile(r"\b\d{5}(?:-\d{4})?\b")
NYC_BOROUGHS_PAT = re.compile(r"\b(brooklyn|queens|manhattan|the bronx|bronx|staten island)\b", flags=re.I)

def load_cities(path: Path) -> Dict[str, str]:
    out = {}
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            out[row["city"].lower()] = row["country_code"]
    return out

DATA_DIR = Path(__file__).parent / "data"
CITY_MAP = load_cities(DATA_DIR / "cities.csv")
CONNECTOR_SPLIT = re.compile(r"\s+(?:and|with|near|in|at|,)\s+", flags=re.I)

def _clean_entity_value(s: str) -> str:
    # Keep the leftmost chunk before common connectors (to avoid "Chapter Roma and maybe NYC")
    first = CONNECTOR_SPLIT.split(s, maxsplit=1)[0]
    return first.strip().strip(" .").lower()

def extract_contact(text: str) -> Dict:
    contact: Dict[str, Optional[str]] = {}
    # Name
    m = NAME_PAT.search(text)
    if m:
        contact["first_name"] = m.group(2)
        if m.group(3):
            contact["last_name"] = m.group(3)
    # Email
    em = EMAIL_PAT.search(text)
    if em:
        contact["email"] = em.group(0)
    # Phone (look for anything that looks like a phone, then attempt normalize)
    phone_candidates = re.findall(r"(\+?\d[\d\-\s()]{6,}\d)", text)
    for cand in phone_candidates:
        normalized = normalize_phone(cand)
        if normalized:
            contact["phone"] = normalized
            break
    # ZIP
    zm = ZIP_PAT.search(text)
    if zm:
        contact["zip"] = zm.group(0)
    return contact

def _best_city_match(text: str) -> List[Tuple[str,str]]:
    # collect unique candidate tokens (lowered)
    lowered = text.lower()
    choices = list(CITY_MAP.keys())
    hits = set()
    # exact substring hits
    for city in choices:
        if city in lowered:
            hits.add(city)
    # fuzzy for tokens capitalized in text (simple heuristic)
    capitalized_phrases = re.findall(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,2})\b", text)
    for phrase in capitalized_phrases:
        match, score, _ = process.extractOne(phrase.lower(), choices, scorer=fuzz.token_set_ratio)
        if score >= 90:
            hits.add(match)
    return [(c, CITY_MAP[c]) for c in hits]

def extract_entities(text: str) -> List[Dict]:
    entities: List[Dict] = []
    lowered = text.lower()

    # Cities (exact/fuzzy)
    for city, _cc in _best_city_match(text):
        entities.append({"type": "city", "value": city})

    # NYC borough alias -> normalize to "new york city"
    if NYC_BOROUGHS_PAT.search(text) and not any(e for e in entities if e["type"]=="city" and e["value"] in ("new york city","new york")):
        entities.append({"type": "city", "value": "new york city"})

    # NYC ZIP prefixes -> normalize to "new york city"
    m = ZIP_ENTITY_PAT.search(text)
    if m and not any(e for e in entities if e["type"]=="city" and e["value"] in ("new york city","new york")):
        zip_prefix = m.group(0)[:3]
        if zip_prefix in {"100","101","102","103","104","111","112","113","114","116"}:
            entities.append({"type": "city", "value": "new york city"})


    # NYC alias
    if re.search(r"\bnyc\b", lowered) and not any(e for e in entities if e["type"]=="city" and e["value"] in ("new york city","new york")):
        entities.append({"type": "city", "value": "new york city"})

    

    # Hotels (non-greedy, then clean)
    hotel_phrases = re.findall(
    r"(?:stay at|hotel|checking in(?:to)?|at)\s+([A-Z][\w&'’\- ]{2,}?(?=(?:\s+(?:and|with|near|in|at)\b|[.,;]|$)))",
    text,
    flags=re.I,
    )
    for hp in hotel_phrases:
        val = _clean_entity_value(hp)
        if val and not any(e for e in entities if e["type"]=="hotel" and e["value"]==val):
            entities.append({"type": "hotel", "value": val})

    # Restaurants
    resto_phrases = re.findall(
    r"(?:dinner at|lunch at|restaurant|reserv(?:ation|e) at)\s+([A-Z][\w&'’\- ]{2,}?(?=(?:\s+(?:and|with|near|in|at)\b|[.,;]|$)))",
    text,
    flags=re.I,
    )
    for rp in resto_phrases:
        val = _clean_entity_value(rp)
        if val and not any(e for e in entities if e["type"]=="restaurant" and e["value"]==val):
            entities.append({"type": "restaurant", "value": val})

    return entities

def cities_to_countries(entities: List[Dict]) -> List[str]:
    seen = set()
    codes: List[str] = []
    for e in entities:
        if e.get("type") == "city":
            city = e.get("value","").lower()
            cc = CITY_MAP.get(city)
            if cc and cc not in seen:
                seen.add(cc)
                codes.append(cc)
    return codes
