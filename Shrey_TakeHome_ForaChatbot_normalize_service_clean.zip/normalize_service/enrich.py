\
from typing import List, Dict, Optional, Iterable
import httpx
from cachetools import TTLCache




# 24h cache for country->numbers
_cache = TTLCache(maxsize=256, ttl=60*60*24)

# add this helper near the top of enrich.py
def _as_str_list(x):
    if x is None:
        return []
    if isinstance(x, (list, tuple, set)):
        return [str(i) for i in x if i is not None]
    return [str(x)]


# Countries where 112 supersedes
USES_112 = set([
    "FR","DE","IT","ES","PT","NL","BE","PL","SE","FI","CZ","SK","HU","AT","GR","IE","RO","BG","HR","SI","CY","EE","LV","LT","LU","MT","IS","NO","TR"
])

def dedupe_numbers(lists: Iterable[Iterable[str]]) -> List[str]:
    seen = set()
    out: List[str] = []
    for lst in lists or []:
        for n in lst or []:
            s = str(n)
            if s and s not in seen:
                seen.add(s)
                out.append(s)
    return out

async def emergency_numbers_for_country(country_code: str, client: Optional[httpx.AsyncClient]=None) -> List[str]:
    cc = country_code.upper()
    if cc in _cache:
        return _cache[cc]

    # 112 countries take precedence
    if cc in USES_112:
        _cache[cc] = ["112"]
        return _cache[cc]

    url = f"https://emergencynumberapi.com/api/country/{cc}"
    close_client = False
    if client is None:
        client = httpx.AsyncClient(timeout=10)
        close_client = True

    numbers: List[str] = []
    try:
        r = await client.get(url)
        r.raise_for_status()
        data = r.json() or {}
        info = data.get("data") or {}
        dispatch = info.get("dispatch") or {}
        police = info.get("police") or {}

        cand = _as_str_list(dispatch.get("all")) or _as_str_list(police.get("all"))
        numbers.extend(cand)
    except Exception:
        # graceful fallback
        if cc == "US":
            numbers = ["911"]
        else:
            numbers = []  # leave empty for unknowns
    finally:
        if close_client:
            await client.aclose()

    _cache[cc] = numbers
    return numbers

