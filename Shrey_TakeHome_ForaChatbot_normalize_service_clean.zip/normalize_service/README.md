# Normalize Service (FastAPI)

A single endpoint `POST /normalize` that classifies a chatbot message, extracts contact + entities, and adds deterministic enrichments. Implements the take-home contract.

## Stack
- FastAPI + Pydantic
- Rules-first classification (regex), optional to extend with LLM
- Heuristic + fuzzy matching for entities, small city catalog
- Deterministic enrichment via emergencynumberapi.com (cached) with graceful fallbacks
- Dockerized, tested (pytest via FastAPI TestClient)

## Run locally
```bash
uv venv .venv && . .venv/bin/activate  # or python -m venv
pip install -r requirements.txt
uvicorn app:app --reload --port 8000
```

## Sample request
```bash
curl -s -X POST http://localhost:8000/normalize \
  -H "Content-Type: application/json" \
  -d '{"message_id":"88e8","text":"Hi Fora, I'''m Alex Smith (917-555-1234) in 10003. My client flies to Rome next week and just lost her passport—help!"}' | jq
```

## Tests
```bash
pip install -r requirements.txt
pytest -q
```

## Deployment
Use the provided Dockerfile:
```bash
docker build -t normalize-service .
docker run -p 8000:8000 normalize-service
```

## Notes
- **Category precedence:** `high_risk` overrides `urgent`.
- **Partial output:** If some fields are missing, they are omitted from the JSON.
- **Emergency numbers:** We call a public deterministic API with a 10s timeout and cache. If unavailable, we fall back to known defaults (`US=911`, EU uses 112).
- **Creative enrichment:** Adds `creative_language` inferred from ISO country code (small local map). Extend easily in `app.py`.
- **City catalog:** Kept tiny for the exercise in `data/cities.csv`. Swap with a richer list for production.

## Roadmap (next steps)
- Add a larger city database and a geo resolver (city -> country).
- Add rate limiting and structured logging sink.
- Optional LLM tiebreaker when rules are inconclusive (with strict JSON schema).
- Expand creative enrichment (nearest consulate phone, FX link).
